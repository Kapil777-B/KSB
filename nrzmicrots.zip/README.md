# rise-dy-translation
Articulate Dynamic Translation in any Langugage
